in phishlet find xxxxxx.com and replace with your hostname .

FIY - this source is optimized to speedup website bcoz of this it might create .evilginx_cache folder in same dir autometically, ingnore that and do not delete any files .

rest setup is same as any other evilginx.

want to go deeper in evilginx ? check out -- https://shop.fluxxset.com/product/evilginx-training-course/